# Jmeter Cluster Support for Kubernetes and OpenShift

## Prerequisits

Kubernetes > 1.16

OpenShift version > 3.5

## TL;DR

```bash
./dockerimages.sh
./jmeter_cluster_create.sh
./dashboard.sh
./start_test.sh
```

Please follow the guide "Load Testing Jmeter On Kubernetes" on our medium blog post:

https://goo.gl/mkoX9E

